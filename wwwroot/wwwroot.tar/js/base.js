function getCookie(key) {

    if (document.cookie.length > 0) {

        var start = document.cookie.indexOf(key + "=");

        if (start !== -1) {

            start = start + key.length + 1;
            var end = document.cookie.indexOf(";", start);
            if (end === -1) end = document.cookie.length;
            return unescape(document.cookie.substring(start, end))
        }
    }

    return ""
}

function navAction() {

    var key = this.getAttribute("href").substr(1);

    if (pageAction.hasOwnProperty(key))

        pageAction[key](document.getElementById(key));
}

document.addEventListener("DOMContentLoaded", function () {

    NavNode.querySelectorAll("li > a").forEach(function (a) {

        if (a.href) {

            a.onclick = navAction;
        }
    });

    pageAction.homeBanner(document.getElementById("home"));

    $(document).on("click", "table.home-banner .operation > span", function () {

        if (homeOperation.hasOwnProperty(this.dataset.action)) {

            homeOperation[this.dataset.action](this.parentNode.dataset, this);
        }
    });

    // $("#homeTxtEditor").Editor();
});

var pageAction = {

    homeBanner: getHomeBanner
};

var homeOperation = {

    up: function (data, node) {

        node = node.parentNode.parentNode;

        if (node.previousSibling) {

            node.parentNode.insertBefore(node, node.previousSibling);

            this.update(node.parentNode);
        }
    },

    down: function (data, node) {

        node = node.parentNode.parentNode;

        if (node.nextElementSibling) {

            if (node.nextElementSibling.nextElementSibling)

                node.parentNode.insertBefore(node, node.nextElementSibling.nextElementSibling);

            else

                node.parentNode.appendChild(node);

            this.update(node.parentNode);
        }
    },

    edit: function (data) {

        editHomeBannerUrl.value = data.href;
        editHomeBannerPic0.src = data.src.substr(data.src.indexOf("\\"));
        editHomeBannerBtn.setAttribute("onclick", "editHomeBanner('" + data.id + "', '" + escape(data.src) + "')");

        requestAnimationFrame(function () {

            editHomeBannerPic.type = "";

            requestAnimationFrame(function () {

                editHomeBannerPic.type = "file";
            });
        });
    },

    del: function (data) {

        $.post("/delHomeBanner", {id: data.id, path: data.src}, function (res) {

            if (res.rc === 0) {

                showTip("删除成功");

                getHomeBanner(true);

            } else

                showTip("删除失败", "label-warning");
        });
    },

    update: function (node) {

        var list = [];

        Array.prototype.forEach.call(node.children, function (tr, i) {

            tr.firstElementChild.innerHTML = i + 1;

            list.push(tr.lastElementChild.dataset.id);
        });

        if (list.length)

            $.post("/sortBanner", {data: list.join(",")}, function (res) {

                if (res.rc === 0)

                    showTip("保存成功");

                else

                    showTip("保存失败", "label-warning");
            });
    }
};

function getHomeBanner(noTip) {

    $.get("/getBanner", function (res) {

        var list = [];

        res.forEach(function (data) {

            var value = new String(data.sort);

            value.html = '<tr><th scope="row">{.sort}</th><td><img src="' + data.src.substr(data.src.indexOf("\\")) + '"/></td>' +
                '<td><a href="' + data.href + '" target="_blank">' + data.href + '</a></td>' +
                '<td class="operation" data-id="' + data._id + '" data-src="' + data.src + '" data-href="' + data.href + '">' +
                '<span class="glyphicon1 glyphicon glyphicon-circle-arrow-up color-info" data-action="up"></span>' +
                '<span class="glyphicon1 glyphicon glyphicon-circle-arrow-down color-warning" data-action="down"></span>' +
                '<span class="glyphicon1 glyphicon glyphicon-remove-sign color-danger" data-action="del"></span>' +
                '<span class="glyphicon1 glyphicon glyphicon glyphicon-info-sign color-primary" data-action="edit"' +
                'data-toggle="modal" data-target="#editHomeBanner"></span>' +
                '</td></tr>';

            list.push(value);
        });

        var html = "";

        list.sort().forEach(function (value, i) {

            html += value.html.replace("{.sort}", i + 1);
        });

        document.querySelector("#homeBanner tbody").innerHTML = html;

        if (noTip !== true)

            showTip("获取轮播数据成功");
    });
}

function editHomeBanner(id, src) {

    var url = editHomeBannerUrl.value.trim();
    var pic = editHomeBannerPic.files[0];

    post("/editHomeBanner", {id: id, href: url, image: pic, src: src}, function (res) {

        if (res.rc === 0) {

            showTip("修改成功");

            getHomeBanner(true);

        } else

            showTip("修改失败", "label-warning");
    });
}

function addHomeBanner() {

    var url = homeBannerUrl.value.trim();
    var pic = homeBannerPic.files[0];

    if (url && pic) {

        post("/addHomeBanner", {href: url, image: pic}, function (res) {

            if (res.rc === 0) {

                showTip("添加成功");

                getHomeBanner(true);

            } else

                showTip("添加失败", "label-warning");
        });
    }
}

function showTip(msg, color) {

    color = color || "label-info";

    requestAnimationFrame(function () {

        tipNode.style.transition = "initial";

        tipNode.className = "label " + color;

        tipNode.innerHTML = msg;

        requestAnimationFrame(function () {

            tipNode.style.transition = "";

            tipNode.className = "label " + color + " opacity-0";
        });
    });
}

function post(url, data, fn) {

    var xhr = XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject("Microsoft.XMLHTTP");

    if (typeof fn === "function") {

        xhr.onreadystatechange = function () {

            if (xhr.readyState === 4) {

                if (xhr.status === 200) {

                    try {

                        fn(JSON.parse(xhr.responseText));

                    } catch (e) {

                        fn(xhr.responseText);
                    }
                }
            }
        };
    }

    xhr.open("POST", url, true);

    var f = document.createElement("form");

    f.enctype = "multipart/form-data";

    var fd = new FormData(f);

    for (var attr in data)

        if (data.hasOwnProperty(attr))

            fd.append(attr, data[attr]);

    xhr.send(fd);
}